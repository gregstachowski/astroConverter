Light Curve Header Keywords (if not a fixed value, example values are in "()")

Keyword            Value                Description  
 
EXTNAME            LIGHTCURVE           Identifies the type of data tabulated.

CONTENT            LIGHTCURVE           Defines the type of data tabulated.

MJDREF             50814.               Modified Julian Date
                                        reference for Chandra data.
                                        Times are in seconds since
                                        this date.
                                     
DATE_OBS           2000-01-17T14:09:39) The date and time the
		   			   observation started. 
 
OBS_ID             (1164)               Chandra Observation Identifier.
 
AGASCID            (1200883536)         AXAF Guide and Aspect Star Catalog ID.
 
TIMEZERO           (64505379.6641316)   Time offset of start of data,
		   			in seconds. 
 
TSTART             (64505379.6641316)   Start of observation, in
		   			seconds since MJDREF. 
 
EXPOSURE           (1940.224)           Exposure time, in seconds.
 
SLOT               (6)                  Guide star software ``slot''.
 
aca_ccd_gain       5.                   ACA calibration data used.
 
aca_ccd_read_noise 25.                  ACA calibration data used.    
 
aca_mag_0          10.32                ACA calibration data used.    
 
aca_rate_mag_0     5263.                ACA calibration data used.
  



Light Curve Table Columns

Name           Unit           Description

time_bin       1              Bin number (starting at 1)

time 	       s              Time at bin center.

time_min       s              Time a start of bin.

time_max       s              Time at end of bin.

counts         counts         Counts, integrated over the time bin.

stat_err       counts         Statistical error on counts.

exposure       s              Exposure time in the bin.

count_rate     counts/s       Mean Count rate in the bin

count_rate_err counts/s       Statistical error on count_rate.

mag            ACA magnitudes Instrumental magnitude

mag_err        ACA magnitude  Statistical error on magnitude.\hline


